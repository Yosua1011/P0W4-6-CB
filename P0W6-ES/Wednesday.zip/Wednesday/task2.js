// const multiply = function (num1, num2) {
// return num1 * num2;
// }
const multiply = (num1, num2) => {
	return num1 * num2;
}

// const divide = function (num1, num2) {
// return num1 / num2;
// }
const divide = (num1, num2) => {
	return num1 / num2;
}


// const doubleMe = function (num) {
// return num * 2;
// }
const doubleMe = num => {
	return num*2;
}

console.log(multiply(5,2));
console.log(divide(10,2));
